"""Create a Windows shortcut for the timer using the current Python install."""
from __future__ import annotations

import argparse
import ctypes
from pathlib import Path
import sys
import uuid

ROOT = Path(__file__).resolve().parent


def find_pythonw() -> Path:
    # Use the interpreter that ran this script, including an activated venv.
    path = Path(sys.executable).resolve().with_name('pythonw.exe')
    if not path.is_file():
        raise FileNotFoundError('pythonw.exe was not found beside the current Python interpreter.')
    return path


def create_shortcut(destination: Path) -> Path:
    if sys.platform != 'win32':
        raise RuntimeError('Windows is required to create a .lnk shortcut.')
    script = ROOT / 'chiikawa_timer.py'
    if not script.is_file() or not (ROOT / 'assets').is_dir():
        raise FileNotFoundError('Keep create_shortcut.py, chiikawa_timer.py and assets in the same folder.')
    pythonw = find_pythonw()
    if destination.suffix.lower() != '.lnk':
        raise ValueError('The destination must end in .lnk.')
    destination = destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)

    class GUID(ctypes.Structure):
        _fields_ = [('Data1', ctypes.c_uint32), ('Data2', ctypes.c_uint16),
                   ('Data3', ctypes.c_uint16), ('Data4', ctypes.c_ubyte * 8)]

    def guid(value):
        return GUID.from_buffer_copy(uuid.UUID(value).bytes_le)

    HRESULT = ctypes.c_long
    ole32 = ctypes.OleDLL('ole32')
    ole32.CoInitializeEx.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    ole32.CoInitializeEx.restype = HRESULT
    ole32.CoCreateInstance.argtypes = [ctypes.POINTER(GUID), ctypes.c_void_p,
        ctypes.c_uint32, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
    ole32.CoCreateInstance.restype = HRESULT
    ole32.CoUninitialize.argtypes = []

    def checked(result):
        if result < 0:
            raise OSError(f'Windows shortcut operation failed: 0x{result & 0xffffffff:08X}')

    def call(pointer, index, arguments, *values):
        table = ctypes.cast(pointer, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        method = ctypes.WINFUNCTYPE(HRESULT, ctypes.c_void_p, *arguments)(table[index])
        result = method(pointer, *values)
        checked(result)

    def release(pointer):
        if pointer.value:
            table = ctypes.cast(pointer, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
            method = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(table[2])
            method(pointer)

    initialized = ole32.CoInitializeEx(None, 2)
    checked(initialized)
    link, persist = ctypes.c_void_p(), ctypes.c_void_p()
    try:
        clsid = guid('00021401-0000-0000-C000-000000000046')
        iid = guid('000214F9-0000-0000-C000-000000000046')
        checked(ole32.CoCreateInstance(ctypes.byref(clsid), None, 1, ctypes.byref(iid), ctypes.byref(link)))
        call(link, 20, [ctypes.c_wchar_p], str(pythonw))
        call(link, 11, [ctypes.c_wchar_p], f'"{script}"')
        call(link, 9, [ctypes.c_wchar_p], str(ROOT))
        call(link, 7, [ctypes.c_wchar_p], '치이카와 타이머 3종 · Python')
        call(link, 15, [ctypes.c_int], 1)
        icon = ROOT / 'chiikawa_timer.ico'
        if icon.is_file():
            call(link, 17, [ctypes.c_wchar_p, ctypes.c_int], str(icon), 0)
        persist_iid = guid('0000010B-0000-0000-C000-000000000046')
        call(link, 0, [ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)],
            ctypes.byref(persist_iid), ctypes.byref(persist))
        call(persist, 6, [ctypes.c_wchar_p, ctypes.c_int], str(destination), 1)
    finally:
        release(persist)
        release(link)
        ole32.CoUninitialize()
    return destination


def main():
    parser = argparse.ArgumentParser(description='Create a local Windows shortcut for the Python timer.')
    parser.add_argument('--output', type=Path, default=ROOT / '치이카와 타이머.lnk',
                        help='Shortcut path; defaults to the program folder.')
    args = parser.parse_args()
    try:
        import PySide6.QtWidgets
        import PySide6.QtMultimedia
        destination = create_shortcut(args.output)
    except (ImportError, OSError, RuntimeError, ValueError) as error:
        print(f'Cannot create shortcut: {error}', file=sys.stderr)
        print('Install dependencies first: py -m pip install -r requirements.txt', file=sys.stderr)
        return 1
    print(f'Shortcut created: {destination}')
    print('Double-click the shortcut. You may copy it to your desktop.')
    print('Keep the program folder in place; recreate the shortcut if it moves.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
